# -*- coding: utf-8 -*-

# Standard modules
import time
import json
import _thread
from queue import Queue
from logging import getLogger

# Third-party modules
import websocket

__all__ = [
    "BinanceWS"
]


class BinanceWS(websocket.WebSocketApp):
    def __init__(self, url, ticker: str, client_timestamp: Queue, delays: Queue, update_ids: Queue):
        super().__init__(url, on_open=self.on_open, on_message=self.on_message,
                         on_close=self.on_close, on_error=self.on_error)
        self.url = url
        self.ticker = ticker
        self.client_timestamp = client_timestamp
        self.delays = delays
        self.update_ids = update_ids
        self.thread_id = None
        self.run_forever()

    def on_message(self, ws, message):
        curr_time = time.time_ns() // 1e6
        data = json.loads(message)
        if data is not None:
            self.update_ids.put(data["u"])
            self.delays.put(curr_time - data["E"])
            self.client_timestamp.put(curr_time)

    def on_error(self, ws, error):
        getLogger(f"{__name__}.on_close").info(f"Error occurred in socket {ws}!\n"
                                               f"Message: {error}")

    def on_close(self, ws):
        getLogger(f"{__name__}.on_close").info(f"Socket {ws} close connection!")

    def on_open(self, ws: websocket.WebSocketApp) -> None:
        def run(*args):
            # Subscribe to the ticker@bookTicker stream
            ws.send(json.dumps({"method": "SUBSCRIBE", "params": [f"{self.ticker}@bookTicker"], "id": 1}))

        getLogger(f"{__name__}.on_close").info(f"Opened websocket {ws} for connections to {self.url}!\n")
        self.thread_id = _thread.start_new_thread(run, ())
        getLogger(f"{__name__}.on_close").info(f"Starting thread {self.thread_id} for websocket {ws}"
                                               f" for connections to {self.url}!\n")
