# -*- coding: utf-8 -*-

# Standard modules
import os
import time
import argparse
import threading
from queue import Queue

# Third-party modules
import pandas as pd

# Project modules
from network import BinanceWS
from constants import ProjectConstants
from binance_logger import init_logger


def get_args():
    parser = argparse.ArgumentParser(prog="Futures delay analyzer",
                                     description="This program connects to Binance futures market via api,"
                                                 "gets data of certain ticker and analyzes the connection delays "
                                                 "distribution.",
                                     usage='python main.py [options] arguments')

    parser.add_argument("-f", "--future", metavar="future", type=str, required=True, dest="future",
                        help="""Specify future's ticker. Example: btcusdt.\n""")
    parser.add_argument("-n", "--number_of_connection", metavar="conn_num", type=int, required=False, dest="conn_num",
                        default=1, help=f"""Specify number of concurrent connections. Default value 1.\n""")
    parser.add_argument("-t", "--timeout", metavar="timeout", type=int, required=False, dest="timeout",
                        default=60, help=f"""Specify timeout in seconds for each connection. Default 60.\n""")
    return parser.parse_args()


if __name__ == "__main__":
    args = vars(get_args())
    init_logger()

    threads_l = []
    client_timestamps_l = [Queue() for _ in range(args["conn_num"])]
    delays_l = [Queue() for _ in range(args["conn_num"])]
    update_ids_l = [Queue() for _ in range(args["conn_num"])]

    for client_timestamps, delays, update_ids in zip(client_timestamps_l, delays_l, update_ids_l):
        thr = threading.Thread(target=BinanceWS, args=(
            ProjectConstants.BINANCE_FUTURES_WS, args["future"],
            client_timestamps, delays, update_ids))
        threads_l.append(thr)
        thr.start()

    time.sleep(args["timeout"])
    for thr in threads_l:
        thr.join(0)

    for i, (update_ids, client_timestamps, delays) in enumerate(zip(update_ids_l, client_timestamps_l, delays_l)):
        update_ids, client_timestamps, delays = list(update_ids.queue), list(client_timestamps.queue), list(
            delays.queue)
        df = pd.DataFrame(list(zip(update_ids, client_timestamps, delays)),
                          columns=["update_id", "client_timestamp", "delay"])
        pth = os.path.join(ProjectConstants.DATA_DIR, f"connection_{i}.pkl")
        df.to_pickle(pth)
        print(f"Data of connection {i} had been saved at {pth}")
